package com.tannia.registration

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {

    private val buttontwo: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_activity)

        val button: Button = findViewById(R.id.btn_two)
        button.setOnClickListener {
            val intent = Intent(this, scheduler::class.java)
            startActivity(intent)

    }
  }
 }